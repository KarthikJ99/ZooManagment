package com.zoo.parking;

public class BikeParking implements IParking {
	private String name;
	private String numberplate;
	private int ticketPrice;
	public int getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(int ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVehnum() {
		return vehnum;
	}
	public void setVehnum(String vehnum) {
		this.vehnum = vehnum;
	}
	
	public void parking()
	{
		BikeParking b=new BikeParking();
		b.setName("KTM");
		b.setTicketPrice(50);
		b.setVehnum("TN4506");
		
		System.out.println(b.getName());
		System.out.println(b.getTicketPrice());
		System.out.println(b.getnumberplate());
	}

	public void Park()
	{
		System.out.println("Park Bike");
	}

	public void Ticket()
	{
		System.out.println(" Ticket for Parking ");
	}

}
