package com.zoo.parking;

public class CarParking implements IParking{
private String name;
private String vehnum;
private int ticketPrice;

public int getTicketPrice() {
	return ticketPrice;
}
public void setTicketPrice(int ticketPrice) {
	this.ticketPrice = ticketPrice;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getVehnum() {
	return vehnum;
}
public void setVehnum(String vehnum) {
	this.vehnum = vehnum;
}


public void parking()
{
	CarParking p=new CarParking();
	p.setName("BMW");
	p.setTicketPrice(500);
	p.setVehnum("TN0008");
	
	System.out.println(p.getName());
	System.out.println(p.getTicketPrice());
	System.out.println(p.getVehnum());
}

public void Park()
{
	System.out.println("Park Car ");
}

public void Ticketcar()
{
	System.out.println("Ticket for parking ");
}
}
