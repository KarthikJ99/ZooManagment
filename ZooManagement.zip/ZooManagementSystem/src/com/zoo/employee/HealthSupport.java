package com.zoo.emp;
import com.zoo.emp.Employee;
public class HealthSupport extends Employee{

	public static void employee() {
	Employee hs=new HealthSupport();
	hs.setName("Karthik");
	hs.setAge(23);
	hs.setContact(9113815205);
	hs.setAddress("Banglore");
	hs.setDesignation("Doctor");

	System.out.println(hs.getName());
	System.out.println(hs.getAge());
	System.out.println(hs.getContact());
	System.out.println(hs.getAddress());
	System.out.println(hs.getDesignation());
	}

	public void job()
	{
		System.out.println(" Gives Treatment");
	}

}
