package com.zoo.emp;
import com.zoo.emp.Employee;

public class SupportEmployee extends Employee {


public static void employee() {
	
SupportEmployee ep=new SupportEmployee();
ep.setName("kiran");
ep.setAge(23);
ep.setContact(7892340021);
ep.setAddress("Mysore");
ep.setDesignation("Boss");

System.out.println(ep.getName());
System.out.println(ep.getAge());
System.out.println(ep.getContact());
System.out.println(ep.getAddress());
System.out.println(ep.getDesignation());
}

public void job()
{
	System.out.println("Pay Salary");
}
}

