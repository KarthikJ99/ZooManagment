package com.zoo.ticket;

public class EntryTicket {
private double price;
private int ticketNum;
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getTicketNum() {
	return ticketNum;
}
public void setTicketNum(int ticketNum) {
	this.ticketNum = ticketNum;
}

public static void Entry() {
	EntryTicket e=new EntryTicket();
	e.setPrice(250);
	e.setTicketNum(3322334);
	System.out.println(e.getPrice());
	System.out.println(e.getTicketNum());
}

public void Welcome()
{
	System.out.println("Welcome to Zoo");
}
}
