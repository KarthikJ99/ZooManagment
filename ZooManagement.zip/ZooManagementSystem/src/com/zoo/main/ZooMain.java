package com.zoo.main;

import com.zoo.emp.HealthSupport;
import com.zoo.emp.SupportEmployee;
import com.zoo.parking.BikeParking;
import com.zoo.parking.CarParking;
import com.zoo.ticket.EntryTicket;
import com.zoo.animal.Animal;
import com.zoo.canteen.Canteen;

public class ZooMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SupportEmployee e=new SupportEmployee();
e.employee();
e.job();

HealthSupport h=new HealthSupport();
h.employee();
e.job();


Animal a=new Animal();
a.animal();
a.sleep();
a.eating();

CarParking c=new CarParking();
c.parking();
c.Park();
c.Ticketcar();

BikeParking b=new BikeParking();
b.parking();
b.Ticket();
b.park();


EntryTicket et=new EntryTicket();
et.Entry();
et.Welcome();


Canteen ca=new Canteen();
ca.canteen();
ca.Breakfast();

}

}
